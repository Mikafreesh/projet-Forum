<?php
echo "Le menu est à placer ici";
?>